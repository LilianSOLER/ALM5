int mul(int a, int b);

int main(void)
{
    int res1,res2,res;
    
    res1 = mul(10, 4);
    res2 = mul(9, 1);
    res= res1+res2;
    return res;
}

