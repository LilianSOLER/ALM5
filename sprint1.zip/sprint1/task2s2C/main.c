int square(int a)
{
    a = a * a;

    return a;
}


int main(void)
{
    int quatre = 4;
    int res = 0;

    // Checkpoint 0

    res = square(quatre);

    // Checkpoint 1

    res = square(res);

    // Checkpoint 2

    while(1);

    return res;
}

