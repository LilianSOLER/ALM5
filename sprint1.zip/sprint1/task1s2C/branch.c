#include <stdio.h>

/************************************************************
  Branchement */

int main ()
{
    int x;

    x = 0;

    while (x < 5) {
        x = x + 1;
        printf("Passage dans la boucle, x=%d \n", x); // impression à l'ecran
    }

    while (1) {} //boucle infini
}

