/***************************************************************************/
/*  Fonctions d'entree/sortie bidon pour permettre l'edition de lien ARM */

int printf (const char* chaine, ...)
{
    return 0;
}
