
function indexOnLoad() {
  multiLang();
}  
