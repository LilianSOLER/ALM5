/***************************************************************************/
/*  Fonctions d'entree/sortie bidon pour permettre l'edition de lien ARM */

int printf (char* chaine, int a)
{
    return(a);
}
int scanf (char* chaine, int* a)
{
    return(*a);
}
int puts (char* chaine)
{
    return(0);
}
