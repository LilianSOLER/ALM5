void print_string(char* t);
int main(void)
{
    char tab[30]="ca marche avec l'appel en C";
    // appel de print_string
    
}

